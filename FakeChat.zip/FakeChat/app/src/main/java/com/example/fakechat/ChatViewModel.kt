import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class ChatViewModel(private val contactId: Long) : ViewModel() {
    private val db = AppDatabase.getInstance(MyApplication.appContext)

    fun sendTextMessage(text: String) {
        viewModelScope.launch {
            db.messageDao().insert(Message(
                contactId = contactId,
                content = text,
                type = "text"
            ))
        }
    }

    fun sendFileMessage(fileUri: Uri) {
        viewModelScope.launch {
            db.messageDao().insert(Message(
                contactId = contactId,
                content = "File attachment",
                type = "file",
                fileUri = fileUri.toString()
            ))
        }
    }
}
