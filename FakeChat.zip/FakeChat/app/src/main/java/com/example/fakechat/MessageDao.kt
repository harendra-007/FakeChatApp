// Add to both ContactDao.kt and MessageDao.kt
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {
    @Insert
    suspend fun insert(message: Message): Long

    @Update
    suspend fun update(message: Message): Int

    @Query("SELECT * FROM message WHERE contactId = :contactId")
    fun getMessages(contactId: Long): Flow<List<Message>>
}



